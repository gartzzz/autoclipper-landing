AutoClipper - Instalacion
=========================

1. DESCOMPRIME este archivo .zip

2. EJECUTA el instalador:
   - Mac:     Doble-click en "install-mac.command"
   - Windows: Doble-click en "install-windows.bat"

3. ABRE Premiere Pro > Window > Extensions > AutoClipper

Backends de IA (elige uno):

  a) Ollama (local, gratis, privado)
     - El instalador detecta tu hardware y recomienda el modelo ideal
     - Descarga desde: https://ollama.com

  b) OpenRouter (nube, gratis)
     - Necesitas una API key: https://openrouter.ai/keys

Soporte y codigo fuente:
https://github.com/gartzzz/autoclipper
