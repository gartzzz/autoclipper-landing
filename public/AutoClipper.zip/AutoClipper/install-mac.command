#!/bin/bash
# AutoClipper Installer for macOS

set -e

echo ""
echo "=================================="
echo "  AutoClipper - Instalador macOS"
echo "=================================="
echo ""

# Resolve the directory where this script lives (the unzipped folder)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
EXTENSION_SRC="$SCRIPT_DIR/extension"

# Target: CEP extensions folder
TARGET_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/com.gartzzz.autoclipper"

# Detect system specs for Ollama recommendation
RAM_BYTES=$(sysctl -n hw.memsize 2>/dev/null || echo "0")
RAM_GB=$((RAM_BYTES / 1073741824))
CHIP=$(sysctl -n machdep.cpu.brand_string 2>/dev/null || echo "Unknown")
IS_APPLE_SILICON=false
if [[ "$CHIP" == *"Apple"* ]]; then
    IS_APPLE_SILICON=true
fi

echo "Hardware detectado:"
echo "  Chip: $CHIP"
echo "  RAM:  ${RAM_GB}GB"
echo ""

# 1. Copy extension
echo "[1/4] Copiando extension a CEP..."
mkdir -p "$TARGET_DIR"
rm -rf "$TARGET_DIR"/*
cp -R "$EXTENSION_SRC/"* "$TARGET_DIR/"
echo "      -> $TARGET_DIR"

# 2. Enable PlayerDebugMode for CSXS.11 and CSXS.12
echo "[2/4] Habilitando modo debug para CEP..."
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
echo "      -> CSXS.11 y CSXS.12 habilitados"

# 3. Check/recommend Ollama
echo "[3/4] Verificando Ollama (IA local)..."

# Determine recommended model based on specs
if [ "$IS_APPLE_SILICON" = true ]; then
    if [ "$RAM_GB" -ge 48 ]; then
        RECOMMENDED_MODEL="gemma3:27b"
        MODEL_REASON="Apple Silicon con ${RAM_GB}GB - modelo grande, maxima calidad"
    elif [ "$RAM_GB" -ge 16 ]; then
        RECOMMENDED_MODEL="gemma3:12b"
        MODEL_REASON="Apple Silicon con ${RAM_GB}GB - excelente calidad"
    else
        RECOMMENDED_MODEL="gemma3:4b"
        MODEL_REASON="Apple Silicon con ${RAM_GB}GB - rapido y eficiente"
    fi
else
    if [ "$RAM_GB" -ge 16 ]; then
        RECOMMENDED_MODEL="gemma3:4b"
        MODEL_REASON="${RAM_GB}GB RAM - modelo eficiente"
    else
        RECOMMENDED_MODEL="gemma3:1b"
        MODEL_REASON="${RAM_GB}GB RAM - modelo ultraligero"
    fi
fi

if command -v ollama &> /dev/null; then
    echo "      -> Ollama instalado: $(ollama --version 2>/dev/null)"

    # Check if recommended model is already downloaded
    if ollama list 2>/dev/null | grep -q "${RECOMMENDED_MODEL%%:*}"; then
        echo "      -> Modelo recomendado ya disponible"
    else
        echo ""
        echo "  Modelo recomendado: $RECOMMENDED_MODEL"
        echo "  Razon: $MODEL_REASON"
        echo ""
        read -p "  Descargar modelo ahora? (s/n): " DOWNLOAD_MODEL
        if [[ "$DOWNLOAD_MODEL" =~ ^[sS]$ ]]; then
            echo "  Descargando $RECOMMENDED_MODEL (puede tardar unos minutos)..."
            ollama pull "$RECOMMENDED_MODEL"
            echo "      -> Modelo descargado"
        else
            echo "      -> Puedes descargarlo luego con: ollama pull $RECOMMENDED_MODEL"
        fi
    fi
else
    echo "      -> Ollama NO instalado"
    echo ""
    echo "  AutoClipper puede usar IA local (gratis, privada) con Ollama."
    echo "  Modelo recomendado para tu equipo: $RECOMMENDED_MODEL"
    echo "  ($MODEL_REASON)"
    echo ""
    echo "  Para instalar:"
    echo "    1. Descarga desde https://ollama.com"
    echo "    2. Abre Ollama"
    echo "    3. En terminal: ollama pull $RECOMMENDED_MODEL"
    echo ""
    echo "  Tambien puedes usar OpenRouter (API en la nube) sin instalar nada."
fi

# 4. Done
echo ""
echo "[4/4] Listo!"
echo ""
echo "=================================="
echo "  Instalacion completada"
echo "=================================="
echo ""
echo "Ahora:"
echo "  1. Abre (o reinicia) Adobe Premiere Pro"
echo "  2. Ve a Window > Extensions > AutoClipper"
if ! command -v ollama &> /dev/null; then
    echo "  3. (Opcional) Instala Ollama para IA local gratuita"
fi
echo ""
echo "Presiona cualquier tecla para cerrar..."
read -n 1 -s
