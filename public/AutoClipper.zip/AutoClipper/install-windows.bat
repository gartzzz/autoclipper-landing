@echo off
chcp 65001 >nul 2>&1
echo.
echo ==================================
echo   AutoClipper - Instalador Windows
echo ==================================
echo.

REM Resolve the directory where this script lives
set "SCRIPT_DIR=%~dp0"
set "EXTENSION_SRC=%SCRIPT_DIR%extension"

REM Target: CEP extensions folder
set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.gartzzz.autoclipper"

REM Detect system RAM
set "RAM_GB=8"
for /f "tokens=2 delims==" %%a in ('wmic computersystem get TotalPhysicalMemory /value 2^>nul ^| find "="') do (
    set /a "RAM_GB=%%a / 1073741824"
)
echo Hardware detectado:
echo   RAM: %RAM_GB%GB
echo.

REM 1. Copy extension
echo [1/4] Copiando extension a CEP...
if exist "%TARGET_DIR%" rmdir /s /q "%TARGET_DIR%"
xcopy "%EXTENSION_SRC%" "%TARGET_DIR%" /E /I /Q /Y
echo       -^> %TARGET_DIR%

REM 2. Enable PlayerDebugMode via registry
echo [2/4] Habilitando modo debug para CEP...
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
echo       -^> CSXS.11 y CSXS.12 habilitados

REM 3. Check Ollama and recommend model
echo [3/4] Verificando Ollama (IA local)...

REM Determine recommended model based on VRAM/RAM
REM On Windows we assume NVIDIA GPU, so VRAM matters more than RAM
REM Without querying GPU directly, use RAM as proxy
set "RECOMMENDED_MODEL=gemma3:4b"
set "MODEL_REASON=%RAM_GB%GB RAM - buen balance"
if %RAM_GB% GEQ 32 (
    set "RECOMMENDED_MODEL=gemma3:12b"
    set "MODEL_REASON=%RAM_GB%GB RAM - alta calidad"
)
if %RAM_GB% LSS 12 (
    set "RECOMMENDED_MODEL=gemma3:1b"
    set "MODEL_REASON=%RAM_GB%GB RAM - modelo ligero"
)

where ollama >nul 2>&1
if %errorlevel% equ 0 (
    echo       -^> Ollama instalado
    ollama list 2>nul | findstr /i "gemma3" >nul 2>&1
    if %errorlevel% equ 0 (
        echo       -^> Modelo recomendado ya disponible
    ) else (
        echo.
        echo   Modelo recomendado: %RECOMMENDED_MODEL%
        echo   Razon: %MODEL_REASON%
        echo.
        echo   Para descargarlo, ejecuta en terminal:
        echo   ollama pull %RECOMMENDED_MODEL%
    )
) else (
    echo       -^> Ollama NO instalado
    echo.
    echo   AutoClipper puede usar IA local (gratis, privada) con Ollama.
    echo   Modelo recomendado: %RECOMMENDED_MODEL%
    echo   (%MODEL_REASON%)
    echo.
    echo   Para instalar:
    echo     1. Descarga desde https://ollama.com
    echo     2. Instala y abre Ollama
    echo     3. En terminal: ollama pull %RECOMMENDED_MODEL%
    echo.
    echo   Tambien puedes usar OpenRouter (API en la nube) sin instalar nada.
)

REM 4. Done
echo.
echo [4/4] Listo!
echo.
echo ==================================
echo   Instalacion completada
echo ==================================
echo.
echo Ahora:
echo   1. Abre (o reinicia) Adobe Premiere Pro
echo   2. Ve a Window ^> Extensions ^> AutoClipper
echo.
pause
